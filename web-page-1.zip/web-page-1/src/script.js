document.queryselector(".clickme").addEventListener("click", () =>{
  document.querySelectorAll('.hidden').forEach((item) => { 
    item.classlist.toggle("showing");
  });
});